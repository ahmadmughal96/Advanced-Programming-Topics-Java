package com.sourcey.materiallogindemo;

import android.util.Base64;
import android.widget.TextView;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;


import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;

public class CertificateActivity
{
    public void decryptString(PublicKey publicKey, String encryptedText) {
        TextView decryptedText = null;
        try {

            Cipher output = Cipher.getInstance("RSA/ECB/PKCS1Padding", "AndroidOpenSSL");
            output.init(Cipher.DECRYPT_MODE, publicKey);

            String cipherText = encryptedText;
            CipherInputStream cipherInputStream = new CipherInputStream(
                    new ByteArrayInputStream(Base64.decode(cipherText, Base64.DEFAULT)), output);
            ArrayList<Byte> values = new ArrayList<>();
            int nextByte;
            while ((nextByte = cipherInputStream.read()) != -1) {
                values.add((byte)nextByte);
            }

            byte[] bytes = new byte[values.size()];
            for(int i = 0; i < bytes.length; i++) {
                bytes[i] = values.get(i).byteValue();
            }

            String finalText = new String(bytes, 0, bytes.length, "UTF-8");
            decryptedText.setText(finalText);

        } catch (Exception e) {
            //Toast.makeText(this, "Exception " + e.getMessage() + " occured", Toast.LENGTH_LONG).show();
            //Log.e(TAG, Log.getStackTraceString(e));
        }
    }

    public boolean createPrivateKeyStore(String password) {

        //if already exists
        File temp = new File("F:\\Connectify\\MyKeyStore.jks");
        if (temp.exists()) {
            return true;
        }
        try {
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            keyStore.load(null, null);
            keyStore.store(new FileOutputStream("F:\\Connectify\\MyKeyStore.jks"), password.toCharArray());
        } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e) {
            e.printStackTrace();
        }
        return true;
    }

    private KeyStore openPrivateKeyStore(char[] password){
        KeyStore keyStore = null;
        try {
            keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            try {
                keyStore.load(new FileInputStream("F:\\Connectify\\MyKeyStore.jks"), password);
            } catch (Exception exp) {
                keyStore.load(null, null);
            }

        } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e) {
            e.printStackTrace();
        }
        return keyStore;
    }

/*
    //Configure and Generate the certificate itself
    public static X509Certificate[] generateCertificate(KeyPair keyPair) {
        MainActivity main = new MainActivity();
        String userID = main.user;
        Date startDate = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000);
        Date endDate = new Date(System.currentTimeMillis() + 2 * 24 * 60 * 60 * 1000);

        X500NameBuilder nameBuilder = new X500NameBuilder(BCStyle.INSTANCE);
        nameBuilder.addRDN(BCStyle.CN, "user");
        nameBuilder.addRDN(BCStyle.SERIALNUMBER, new BigInteger(128, new Random()).toString(16));

        X500Name x500Name = nameBuilder.build();
        Random random = new Random();

        SubjectPublicKeyInfo subjectPublicKeyInfo = SubjectPublicKeyInfo.getInstance(keyPair.getPublic().getEncoded());
        X509v1CertificateBuilder v1CertGen = new X509v1CertificateBuilder(x500Name
                , BigInteger.valueOf(random.nextLong())
                ,startDate
                ,endDate
                ,x500Name
                ,subjectPublicKeyInfo);

        // Prepare Signature:
        ContentSigner sigGen = null;
        try {
            Security.addProvider(new BouncyCastleProvider());
            sigGen = new JcaContentSignerBuilder("SHA256WithRSAEncryption").setProvider("SC").build(keyPair.getPrivate());
        } catch (OperatorCreationException e) {
            e.printStackTrace();
        }
        // Self sign :
        X509CertificateHolder x509CertificateHolder = v1CertGen.build(sigGen);

        CertificateFactory certFactory = null;
        InputStream in = null;
        X509Certificate[] chain = new X509Certificate[1];
        try {
            certFactory = CertificateFactory.getInstance("X.509");
            in = new ByteArrayInputStream(x509CertificateHolder.getEncoded());
            chain[0] = (X509Certificate) certFactory.generateCertificate(in);

        } catch (CertificateException |IOException e) {
            e.printStackTrace();
        }
        return chain;  //returning X509 certificate
        return null;
    }
    public boolean storePrivateKeywithCertificate(String password, X509Certificate[] chain, PrivateKey key){
        try {
            createPrivateKeyStore(password);
            KeyStore keyStore = this.openPrivateKeyStore(password.toCharArray());
            keyStore.setKeyEntry("signing-key", key, password.toCharArray(), chain);
            keyStore.store(new FileOutputStream("F:\\Connectify\\MyKeyStore.jks"), password.toCharArray());
        } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e) {
            e.printStackTrace();
        }
        return true;
    }

    public PrivateKey fetchPrivateKey(String password, String distinguishName){
        PrivateKey privateKey = null;
        if (null == distinguishName) {
            throw new NullPointerException("Common name is null !");
        }
        try {
            KeyStore keyStore = this.openPrivateKeyStore(password.toCharArray());
            privateKey = (PrivateKey) keyStore.getKey(distinguishName, password.toCharArray());
        } catch (UnrecoverableKeyException | KeyStoreException | NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return privateKey;
    }

    public X509Certificate[] fetchCertificateChain(String password, String distinguishName){
        if (null == distinguishName) {
            throw new NullPointerException("Common name is null !");
        }
        X509Certificate x509Certificate[] = null;
        try {
            KeyStore keyStore = this.openPrivateKeyStore(password.toCharArray());
            java.security.cert.Certificate[] chain = null;
            chain = keyStore.getCertificateChain(distinguishName);
            if (chain == null) {

                new NullPointerException("Problems when fetching chain of " + distinguishName.toString());
            }
            x509Certificate = new X509Certificate[chain.length];
            for (int i = 0; i < chain.length; i++) {
                x509Certificate[i] = (X509Certificate) chain[i];
            }

        } catch (KeyStoreException e) {
            e.printStackTrace();
        }
        return x509Certificate;
    }
*/
}
